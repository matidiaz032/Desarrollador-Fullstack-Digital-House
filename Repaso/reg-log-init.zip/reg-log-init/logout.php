<?php
require("funciones.php");
logout();
header("Location:inicio.php");exit;

?>
