<?php
$ceu = [
  "Argentina" => [
    "Buenos Aires", 
    "Córdoba", 
    "Santa Fé"
  ],
  "Brasil" => ["Brasilia", "Rio de Janeiro", "Sao Pablo"],
  "Colombia" => ["Cartagena", "Bogota", "Barranquilla"],
  "Francia" => ["Paris", "Nantes", "Lyon"],
  "Italia" => ["Roma", "Milan", "Venecia"],
  "Alemania" => ["Munich", "Berlin", "Frankfurt"]
];
